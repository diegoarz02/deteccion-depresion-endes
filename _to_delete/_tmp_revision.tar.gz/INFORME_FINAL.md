# Informe final

**Proyecto:** Modelamiento epidemiológico de la depresión en la población peruana de 15 y más años (ENDES 2025)
**Autor:** Diego Alonso Araujo Villegas — UNMSM, Facultad de Ciencias Matemáticas
**Fecha:** 31 de agosto de 2026

---

## 1. Qué cambió en esta corrida, y por qué

### 1.1 El reencuadre de la aplicación

La aplicación mostraba una **probabilidad personal en grande**: 19,9 %, con su barra y su
etiqueta de «riesgo alto». Técnicamente correcta y, aun así, inaceptable.

La razón es aritmética. Con un valor predictivo positivo de 0,147, de cada cien personas
que el modelo señala como riesgo, unas ochenta y cinco no dan positivo en el tamizaje.
Una cifra presentada como propia es falsa cinco de cada seis veces. En salud mental eso
no es un tecnicismo: angustia a quien no lo necesita y tranquiliza a quien sí.

**No se eliminó nada. Se reordenó y se renombró con honestidad.**

El número protagonista pasa a ser un hecho observado:

> **17,7 de cada 100**
> Entre las personas del mismo sexo, grupo de edad, nivel educativo, área de residencia y
> región natural entrevistadas en la ENDES 2025, esa proporción dio positivo al tamizaje
> PHQ-9. Sobre 513 personas, de las cuales 92 dieron positivo. IC 95 %: 13,9 % a 22,2 %.

La segunda afirmación es **verificable**: describe la muestra, y cualquiera con los
microdatos puede comprobarla. La primera era una extrapolación que estos datos no
sostienen.

La estimación del modelo sigue ahí, con un tercio del tamaño tipográfico y nombrada como
«estimación del modelo para este perfil», nunca como «tu probabilidad».

**Cómo se construye un «perfil parecido» que no engañe.** Un cruce de cinco variables deja
celdas minúsculas. Se hace un descenso jerárquico —del cruce completo hasta sexo y edad— y
se **declara qué variables definen la celda** en lugar de un vago «parecido». El criterio
para usar una celda no es su tamaño sino el **número de eventos**: con un desenlace del
7 %, una celda de 120 personas puede tener 8 positivos. Con n ≥ 100 y ≥ 20 eventos, el
31 % de los perfiles obtiene el cruce completo, el 30 % cuatro variables, el 21 % tres y
el 18 % dos. Nadie cae hasta «solo sexo».

### 1.2 El panel de límites

Cuatro tarjetas con el mismo peso visual que el resultado, no un pie de página gris:

| | |
|---|---|
| **2 de cada 3** | Lo que acierta el modelo distinguiendo dos personas al azar (AUC 0,67) |
| **85 de 100** | Las que señala como riesgo y no dan positivo (VPP 0,147) |
| **93,8 %** | Lo que acierta responder «nadie», más que el 89,4 % del modelo |
| **4 de 4** | Familias de algoritmos con el mismo resultado: es el techo, no el método |

### 1.3 El guardarraíl que faltaba

El agente ya bloqueaba «usted tiene depresión». No bloqueaba **«tu probabilidad es del
19,9 %»**, que suena técnico y prudente y hace el mismo daño: adjudica a una persona una
cifra que solo describe a un grupo.

Los patrones nuevos exigen la segunda persona **junto a** una cifra. Hablar en segunda
persona no es el problema; hacerlo para adjudicar un número, sí.

### 1.4 La identidad visual

El diseño anterior era correcto y anónimo: un azul marino institucional que servía igual
para un banco, una aseguradora o un ministerio.

- **Verde-teal como voz principal** — el color del lazo internacional de la salud mental.
- **Fondo de papel cálido**, no blanco clínico ni gris azulado. El blanco puro es el color
  del formulario médico; quien lee esto puede estar buscándose en las cifras.
- **Neutros de base tierra** en lugar de grises fríos.
- **Terracota como acento, no rojo de alarma.** El rojo señala emergencia, y aquí se habla
  de prevalencias poblacionales. El ciruela queda para el bloque de crisis.
- **Serif humanista en titulares** (Fraunces sobre Inter).

Vive en `codigo/src/depresion/diseno.py` y alimenta boletín, aplicación y figuras de
matplotlib desde un solo sitio. Los 14 pares de texto y fondo del modo claro y los 8 del
oscuro superan WCAG AA.

### 1.5 El explorador del boletín

El boletín gana un explorador de tasas observadas que **funciona sin servidor**: el
catálogo de 20 kB va incrustado en la página. GitHub Pages no tiene backend, y depender
del servicio de Render metería un arranque en frío de un minuto justo cuando alguien está
interactuando. Es además el reencuadre llevado al extremo: aquí no hay modelo, solo el
recuento.

---

## 2. El argumento del techo predictivo

*Este es el párrafo que defiende el trabajo ante el jurado.*

El modelo tiene un AUC de 0,667 (IC 0,655–0,679). Puestas dos personas al azar, una con
síntomas depresivos y otra sin ellos, acierta cuál es cuál dos de cada tres veces. El
valor predictivo positivo es 0,147, la mejora del error de calibración frente a no tener
modelo es del 2,2 %, y su exactitud —89,4 %— es **peor** que la de responder «nadie tiene
depresión» a todo el mundo, que acierta el 93,8 %.

**Estos números no son un fracaso del análisis. Son el resultado correcto, y hay tres
razones para afirmarlo.**

**Primera: cuatro familias de algoritmos dan casi lo mismo.** Un bosque aleatorio, dos
implementaciones de *boosting* y una regresión logística regularizada caben todas entre
0,655 y 0,684 de AUC. Cuando cambiar de método no cambia el resultado, el límite no está
en el método: está en la información disponible. No hay un algoritmo mejor esperando a ser
encontrado.

**Segunda: era esperable por la naturaleza del fenómeno.** La depresión de una persona
depende de su historia, sus duelos, su red de apoyo, su situación económica inmediata y su
biología. Una encuesta de hogares mide sexo, edad, educación, dónde vive y unas pocas
conductas. Con esas variables se puede describir **dónde se concentra** el problema en el
país —y eso este trabajo lo hace bien: intervalos estrechos, gradientes coherentes con la
literatura, y una réplica del tramo alto del estudio sobre la ENDES 2019 con aPR 1,37
frente al 1,41 reportado—. Lo que no se puede es saber quién lo tiene. Son dos preguntas
distintas y solo una tiene respuesta con estos datos.

**Tercera, y la más importante: un AUC alto habría sido motivo de sospecha.** En la ENDES,
las preguntas `QS702` y `QS704A–I` se formulan únicamente a quien ya marcó síntomas en el
bloque anterior. Su sola cobertura *es* el desenlace disfrazado. Incluirlas habría dado un
modelo espectacular y completamente inútil. Se excluyeron desde el primer día, y el precio
de esa decisión correcta es justamente el techo de 0,67. **El techo bajo es la prueba de
que no hay fuga de información.**

Por eso el trabajo no maquilla el resultado: lo explica. Un modelo con AUC 0,67 bien
comunicado orienta política pública sin prometer nada falso —dice qué departamentos
priorizar, qué grupos concentran la carga, dónde la brecha de atención es peor—. El mismo
modelo presentado como «detector» invita a usarlo sobre personas concretas, donde se
equivoca cinco de cada seis veces. La diferencia entre las dos cosas es solo de
comunicación, y es toda la diferencia.

---

## 3. Estado de cada corrección

| § | Corrección | Estado |
|---|---|---|
| 1.3 | Resultado principal = hecho observado | ✅ `/tasa-observada`, 87 celdas publicables |
| 1.3 | Panel «Por qué este número no te describe a ti» | ✅ Cuatro tarjetas, peso visual propio |
| 1.3 | Agente: prohibida la atribución personal | ✅ 8 patrones nuevos, 11 pruebas |
| 1.3 | Interfaz renombrada a «explorador» | ✅ Título, marca y descripción |
| 2.1 | Marcar CV > 0,20 en todas las tablas | ✅ Automático en `guardar_tabla`; 2 tablas marcadas |
| 2.2 | Tramo intermedio como relación en J | ✅ Sección propia en el boletín, sin afirmar causalidad |
| 2.3 | Disclaimer en todas las páginas | ✅ 13 de 13, en el pie compartido |
| 2.4 | Reproducibilidad del entorno | ✅ Python fijado, `ENDES_SAV` por entorno, bloque exacto en README |
| 2.5 | Limpieza de código | ✅ ruff limpio, 104 pruebas, sin rutas absolutas ni docstrings faltantes |
| — | Identidad visual del tema | ✅ Paleta, tipografía y tokens compartidos; AA en claro y oscuro |
| — | Explorador sin servidor en el boletín | ✅ Catálogo incrustado, 20 kB |

**`black` no se ejecutó**: no está instalado y `ruff format` cubre lo mismo. El objetivo
`calidad` del Makefile ya solo llama a ruff.

---

## 4. URLs

**Ninguna está publicada todavía**, por decisión tuya. Lo que hay preparado:

| Destino | URL prevista | Estado |
|---|---|---|
| Repositorio | `github.com/diegoarz02/deteccion-depresion-endes` | Local, 17 commits, **sin remoto** |
| Boletín | GitHub Pages sobre `boletin/` | Generado, funciona sin backend |
| Aplicación | `depresion-endes.onrender.com` | `render.yaml` listo, runtime nativo |

Las URL aparecen como marcador en el boletín y el README. **Hay que sustituirlas por las
reales tras el primer despliegue y regenerar el sitio** — es lo que más se olvida.

---

## 5. Lo que queda pendiente o sin verificar

- **No se ha desplegado nada.** Ni GitHub ni Render. Todo preparado y verificado en local.
- **El consumo de memoria en Render no está medido.** El razonamiento dice que entra
  holgado —el servicio solo carga FastAPI, Pydantic y un JSON de coeficientes— pero no se
  ha comprobado con el servicio arriba.
- **El arranque en frío no se ha cronometrado.** La interfaz avisa, pero no sé cuánto tarda
  de verdad.
- **El tramo intermedio de altitud** contradice al estudio de 2019 y no tengo explicación.
  Queda reportado como pregunta abierta, no resuelto.
- **La Puna** publica su prevalencia con CV 0,222. Marcada, no suprimida.
- **El punto de corte del PHQ-9 en 10** no está validado para población peruana. Se
  mantiene por comparabilidad, con sensibilidad en ≥ 5.
- **`make` no está instalado** en esta máquina. El Makefile sirve como documentación y para
  CI; todos los pasos se corrieron con `python` directo.
- **El PAT de GitHub sigue sin revocar.** `gh` ya está autenticado con la misma cuenta, así
  que es redundante. Está solo en `.env`, cubierto por `.gitignore`, y el escaneo del árbol
  no encuentra nada.
- **Ninguna de las 32 habilidades listadas en el prompt estaba disponible** en la sesión.
  El trabajo se hizo con las herramientas base.

---

## 6. Guion para la sustentación

### Hilo narrativo (12–15 minutos)

**1 · El problema, no el método** (2 min)
Abre con la brecha de atención: **87,5 % de las personas con tamizaje positivo no recibió
atención profesional**. En Cusco, 96 de cada 100. Esa es la cifra que justifica el trabajo.

**2 · De dónde salen los datos** (2 min)
Flujograma STROBE: 33 569 entrevistas → 30 226 analizables. Diseño complejo declarado.
Menciona el **efecto de diseño de 3,09**: las 30 226 entrevistas informan como 9 774
tomadas al azar. Ignorarlo daría intervalos la mitad de anchos de lo que corresponde.

**3 · Quiénes y dónde** (3 min)
La brecha por sexo (9,87 % frente a 3,86 %) es la mayor del estudio. La curva en U por
edad. Y el mapa: Puno 12,8 % frente a Ucayali 1,1 %.
*Muestra el explorador del boletín en vivo* — cruza sexo, edad, educación y región, y sale
un recuento real con su intervalo.

**4 · El resultado que más enseña** (2 min)
La paradoja del tabaco: OR crudo 0,72, parece protector; al ajustar por sexo se invierte a
1,44. Los hombres fuman más y tienen menos depresión. Es el ejemplo de confusión de libro
de texto, y salió de estos datos.

**5 · El modelo, y su techo** (3 min)
Aquí va el argumento de la sección 2. No lo escondas al final: cuéntalo como resultado.
*Muestra el panel de límites de la aplicación.*

**6 · Cierre** (2 min)
Réplica en R: 17 términos, discrepancia máxima 0,00047. Y la frase de cierre: el trabajo
sirve para orientar dónde poner recursos, no para decidir sobre nadie.

### Qué mostrar, en qué orden

1. El boletín, sección 7 (Dónde) — los mapas entran solos.
2. El explorador del boletín, en vivo.
3. La aplicación: perfil, resultado observado, y **el panel de límites**.
4. Una tabla con la marca de CV en la Puna, si preguntan por precisión.

### Las tres preguntas difíciles

**«¿Un AUC de 0,67 no es muy bajo? ¿No sirve el modelo?»**
Es bajo, y es el resultado correcto. Cuatro familias de algoritmos dan entre 0,655 y 0,684:
cuando cambiar de método no cambia nada, el techo está en los datos, no en el método. Una
encuesta de hogares no mide duelos, apoyo social ni historia personal, que es lo que
determina la depresión de alguien. Y hay un argumento más fuerte: **si hubiera salido 0,90
habría que sospechar**. Las preguntas `QS702` y `QS704` de la ENDES se hacen solo a quien
ya marcó síntomas; incluirlas da un modelo espectacular e inútil. Las excluimos, y el techo
bajo es la prueba de que no hay fuga. El modelo sirve para lo que se diseñó: comparar
grupos y orientar política pública.

**«La altitud, ¿causa depresión?»**
No podemos afirmarlo, y el diseño no lo permite: es transversal, mide exposición y
desenlace a la vez. Lo que sí encontramos es una asociación que **replica** el estudio
sobre la ENDES 2019 en el tramo alto —aPR 1,37 frente a 1,41 reportado, con intervalos que
se solapan casi enteros—. Y encontramos algo que ese estudio no vio: la relación no es
lineal, tiene forma de J, con el tramo intermedio por debajo de la costa. En ese tramo
nuestro resultado **contradice** al suyo y no tenemos explicación; lo reportamos como
discrepancia abierta. Además, en el Perú la altura viene con ruralidad, pobreza, lengua
originaria y menos servicios de salud, y ninguna de esas la pudimos ajustar.

**«¿Por qué la aplicación no me dice mi probabilidad?»**
Porque no puede decirla con honestidad. El valor predictivo positivo es 0,147: de cada cien
personas que el modelo señala, unas ochenta y cinco no dan positivo. Un número personal así
sería falso cinco de cada seis veces, y en salud mental eso hace daño en las dos
direcciones. Lo que sí podemos decir con certeza es cuántas personas parecidas dieron
positivo en la encuesta, que es un recuento verificable sobre 30 226 entrevistas. La
estimación del modelo sigue en la página, en segundo plano y nombrada como lo que es.

---

## 7. Cifras para tener a mano

| | |
|---|---|
| Muestra analítica | 30 226 (de 33 569 entrevistas) |
| Prevalencia nacional | 6,98 % (IC 6,49–7,51) |
| Brecha de atención | 87,5 % · Cusco 96,2 % |
| Mujer / hombre | 9,87 % / 3,86 % |
| Sierra / Costa / Selva | 8,04 % / 6,90 % / 4,97 % |
| Efecto de diseño | 3,09 · muestra efectiva 9 774 |
| OR ajustado más alto | Alcohol problemático 6,07 (3,41–10,82) |
| Altitud ≥ 2 500 m | aPR 1,37 (1,24–1,52) · el estudio de 2019 dio 1,41 |
| AUC | 0,667 (0,655–0,679) |
| Valor predictivo positivo | 0,147 |
| Modelo trivial | 93,8 % de exactitud, frente al 89,4 % del modelo |
| Réplica en R | 17 términos, discrepancia máxima 0,00047 |
| Pruebas | 104, todas en verde |
